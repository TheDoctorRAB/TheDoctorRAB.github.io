### Put images for the homework in this directory. 
### The tex file has the directory path set. 
